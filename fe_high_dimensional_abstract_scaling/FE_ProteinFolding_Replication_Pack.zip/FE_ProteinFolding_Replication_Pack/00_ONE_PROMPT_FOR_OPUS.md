## SINGLE PROMPT FOR OPUS (copy/paste as-is)

Mission:
Run a full, scientifically clean replication experiment comparing **Forgetting Engine (FE)** vs **Monte Carlo (MC)** on lattice protein folding benchmarks across increasing complexity (2D→3D and increasing sequence length). Use the repo code already present. Use *one* configuration file and do not ask the user follow-up questions unless execution fails.

Rules:
- Use fixed random seeds.
- Log every trial.
- Output a single CSV with one row per trial and a single JSON summary.
- Treat feasibility as “reached known global optimum energy” for that instance (or the repo’s success criterion if already defined).
- Use the standardized columns described in this pack.
- Produce an analysis report with success rates, confidence intervals, and a short interpretation focused on reproducibility.

Execution plan:
1) Read `config.json` in this folder and verify paths.
2) Run the sweep described in `config.json` (default: 4000 trials total; balanced FE/MC).
3) Write outputs to `results/`.
4) Run `analyze_results.py` to generate tables + figures.
5) Print a brief completion note with file paths.

Important:
- Do NOT change the scientific framing or introduce consciousness language.
- Keep tone publication-optimized (dry, precise).