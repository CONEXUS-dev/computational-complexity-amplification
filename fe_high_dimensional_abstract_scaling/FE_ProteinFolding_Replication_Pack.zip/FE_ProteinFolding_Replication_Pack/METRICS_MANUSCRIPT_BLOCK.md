# Evaluation Metrics (manuscript-ready)

Let each trial terminate at iteration \(T\). Let \(E_t\) be the energy of the current conformation at iteration \(t\) and \(E^\*\) be the known global optimum energy for the benchmark instance (or the accepted optimum value provided by the benchmark set).

**Final energy.**
\[
E_{\mathrm{final}} = E_T
\]

**Best energy achieved.**
\[
E_{\mathrm{best}} = \min_{t \in \{1,\dots,T\}} E_t
\]

**Success indicator.**
\[
\mathbf{1}_{\mathrm{success}} =
\begin{cases}
1 & \text{if } E_{\mathrm{best}} \le E^\* \\
0 & \text{otherwise}
\end{cases}
\]

**Success rate (over \(N\) trials).**
\[
SR = \frac{1}{N}\sum_{i=1}^{N} \mathbf{1}_{\mathrm{success}}^{(i)}
\]

**Relative improvement in success rate (FE over MC).**
\[
\mathrm{Improvement}(\%) = 100 \times \frac{SR_{\mathrm{FE}} - SR_{\mathrm{MC}}}{SR_{\mathrm{MC}}}
\]

(Insert your concrete numeric example immediately after first percentage claim.)