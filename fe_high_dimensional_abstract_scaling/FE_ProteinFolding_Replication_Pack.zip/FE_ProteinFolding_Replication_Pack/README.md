# FE Protein Folding Replication Pack (single-prompt Opus / one-command run)

This folder is designed so you can hand **one prompt** to an AI runner (Opus / Windsurf / etc.)
and have it **plan + execute the full replication** without additional back-and-forth.

## What this pack does
1. Runs a controlled benchmark comparison:
   - Baseline: Monte Carlo (MC) / Simulated Annealing style local move search
   - Treatment: Forgetting Engine (FE) (your implementation)
2. Produces a standardized results CSV.
3. Generates an analysis report with:
   - Success rate and 95% Wilson CI
   - Mean final energy ± SD
   - Best energy achieved
   - Effect sizes and permutation test p-value (optional)
   - Figures ready for manuscript insertion

## You only need to fill 3 placeholders
Open `config.json` and set:
- `fe_command`: command that runs one FE trial given a seed + instance id
- `mc_command`: command that runs one MC trial given a seed + instance id
- `instances_path`: JSON/CSV describing the benchmark instances you want to run

Everything else is automatic.

## One-command usage
```bash
python run_experiment.py --config config.json
python analyze_results.py --results results/results.csv --out results/analysis
```

## Notes
- This pack does NOT implement your proprietary FE internals. It orchestrates *your* runner.
- Outputs are deterministic if your runners respect `--seed`.