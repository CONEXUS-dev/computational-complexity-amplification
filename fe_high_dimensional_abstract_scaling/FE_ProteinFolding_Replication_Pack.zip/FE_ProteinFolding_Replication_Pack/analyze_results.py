#!/usr/bin/env python3

analyze_results.py

Computes publishable metrics + tables from results.csv.

Usage:
  python analyze_results.py --results results/results.csv --out results/analysis

import argparse, os, math, json
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    phat = k / n
    denom = 1 + z*z/n
    center = (phat + z*z/(2*n)) / denom
    half = (z * math.sqrt((phat*(1-phat) + z*z/(4*n))/n)) / denom
    return (center - half, center + half)

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    out = Path(args.out)
    ensure_dir(out)

    df = pd.read_csv(args.results)

    # Basic cleaning
    df_ok = df[df["status"].astype(str).str.startswith("OK")].copy()

    # Aggregate by algorithm overall and by complexity bins
    def summarize(group_cols):
        g = df_ok.groupby(group_cols, dropna=False)
        rows = []
        for keys, sub in g:
            if not isinstance(keys, tuple):
                keys = (keys,)
            k = int(sub["success_flag"].sum())
            n = int(sub["success_flag"].count())
            sr = k / n if n else np.nan
            lo, hi = wilson_ci(k, n)
            rows.append({
                **{group_cols[i]: keys[i] for i in range(len(group_cols))},
                "n": n,
                "successes": k,
                "success_rate": sr,
                "sr_ci_low": lo,
                "sr_ci_high": hi,
                "mean_final_energy": float(np.nanmean(sub["final_energy"])) if "final_energy" in sub else np.nan,
                "sd_final_energy": float(np.nanstd(sub["final_energy"], ddof=1)) if n > 1 else np.nan,
                "best_energy_min": float(np.nanmin(sub["best_energy"])) if "best_energy" in sub else np.nan,
                "median_runtime_s": float(np.nanmedian(sub["runtime_s"])) if "runtime_s" in sub else np.nan,
            })
        return pd.DataFrame(rows)

    overall = summarize(["algorithm"])
    by_dim_len = summarize(["dimension","sequence_length","algorithm"]).sort_values(["dimension","sequence_length","algorithm"])

    overall.to_csv(out / "table_overall.csv", index=False)
    by_dim_len.to_csv(out / "table_by_dimension_length.csv", index=False)

    # Plot success rate by sequence length for each dimension
    for dim in sorted(df_ok["dimension"].dropna().unique()):
        sub = by_dim_len[by_dim_len["dimension"] == dim]
        if sub.empty:
            continue
        plt.figure()
        for algo in sub["algorithm"].unique():
            a = sub[sub["algorithm"] == algo].sort_values("sequence_length")
            plt.errorbar(
                a["sequence_length"],
                a["success_rate"],
                yerr=[a["success_rate"]-a["sr_ci_low"], a["sr_ci_high"]-a["success_rate"]],
                label=str(algo),
                marker="o",
                linestyle="-",
            )
        plt.xlabel("Sequence length")
        plt.ylabel("Success rate (global optimum reached)")
        plt.title(f"Success rate vs length (dimension={dim})")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / f"fig_success_rate_dim{dim}.png", dpi=200)
        plt.close()

    # Produce a short JSON summary for manuscript insertion
    summary = {
        "overall": overall.to_dict(orient="records"),
        "by_dimension_length": by_dim_len.to_dict(orient="records"),
        "notes": [
            "Success CIs: 95% Wilson interval.",
            "Use tables/figures as-is in manuscript or supplement."
        ]
    }
    with open(out / "analysis_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print("Wrote analysis outputs to:", out)

if __name__ == "__main__":
    main()