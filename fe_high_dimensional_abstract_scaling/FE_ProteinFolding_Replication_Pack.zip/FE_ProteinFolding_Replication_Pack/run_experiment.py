#!/usr/bin/env python3

run_experiment.py

Orchestrates FE vs MC experiment using external commands defined in config.json.

Design goals:
- Minimal assumptions about your private FE implementation.
- Deterministic trial bookkeeping.
- Standardized results CSV for publication.

Usage:
  python run_experiment.py --config config.json

import argparse, json, os, subprocess, time, uuid
from pathlib import Path
import pandas as pd

def safe_mkdir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def render_cmd(template: str, **kwargs) -> str:
    for k,v in kwargs.items():
        template = template.replace("{"+k+"}", str(v))
    return template

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    base = Path(cfg.get("out_dir", "results"))
    safe_mkdir(base)
    raw_dir = base / "raw"
    safe_mkdir(raw_dir)

    # Load instances
    inst_path = Path(cfg["instances_path"])
    if not inst_path.exists():
        raise FileNotFoundError(f"instances_path not found: {inst_path}")

    with open(inst_path, "r", encoding="utf-8") as f:
        instances = json.load(f)

    seeds = cfg["seeds"]
    repeats = int(cfg.get("repeats_per_seed", 1))
    algos = cfg["algorithms"]

    rows = []
    trial_counter = 0

    for inst in instances:
        instance_id = inst["instance_id"]
        dimension = int(inst.get("dimension", 3))
        seq_len = int(inst.get("sequence_length", -1))

        for seed in seeds:
            for rep in range(repeats):
                for algo in algos:
                    trial_id = trial_counter
                    trial_counter += 1

                    out_json = raw_dir / f"{trial_id}_{algo['name']}_{instance_id}_s{seed}_r{rep}.json"

                    cmd = render_cmd(
                        algo["command"],
                        instance_id=instance_id,
                        seed=seed,
                        out_json=str(out_json),
                    )

                    t0 = time.time()
                    proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    rt = time.time() - t0

                    # Expect the runner to write a JSON file with at least:
                    # final_energy, best_energy, success_flag, n_iterations, paradox_activity (optional)
                    if not out_json.exists():
                        # Log failure but keep experiment moving
                        rows.append({
                            "trial_id": trial_id,
                            "algorithm": algo["name"],
                            "instance_id": instance_id,
                            "dimension": dimension,
                            "sequence_length": seq_len,
                            "seed": seed,
                            "final_energy": None,
                            "best_energy": None,
                            "success_flag": False,
                            "n_iterations": None,
                            "runtime_s": rt,
                            "paradox_activity": None,
                            "stderr": proc.stderr[:2000],
                            "stdout": proc.stdout[:2000],
                            "status": "NO_OUTPUT_JSON",
                        })
                        continue

                    with open(out_json, "r", encoding="utf-8") as f:
                        out = json.load(f)

                    rows.append({
                        "trial_id": trial_id,
                        "algorithm": algo["name"],
                        "instance_id": instance_id,
                        "dimension": dimension,
                        "sequence_length": seq_len,
                        "seed": seed,
                        "final_energy": out.get("final_energy"),
                        "best_energy": out.get("best_energy", out.get("final_energy")),
                        "success_flag": bool(out.get("success_flag", False)),
                        "n_iterations": out.get("n_iterations"),
                        "runtime_s": out.get("runtime_s", rt),
                        "paradox_activity": out.get("paradox_activity", out.get("paradox_activity_count")),
                        "status": "OK" if proc.returncode == 0 else f"RC_{proc.returncode}",
                    })

    df = pd.DataFrame(rows)
    out_csv = base / "results.csv"
    df.to_csv(out_csv, index=False)

    summary = {
        "experiment_name": cfg.get("experiment_name", ""),
        "n_trials": int(len(df)),
        "results_csv": str(out_csv),
        "raw_dir": str(raw_dir),
        "note": "Analyze with analyze_results.py",
    }
    with open(base / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(f"Done. Wrote {len(df)} rows to {out_csv}")
    print(f"Summary: {base / 'summary.json'}")

if __name__ == "__main__":
    main()